package Loan;
import java.util.Scanner;

public class Calculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		double Lease_amount = 0;
		double interest_rate = 0;
		int repayment_period = 0;
		double rental_value = 0;
		double interest_amount,capital_amount,capital_balance;
		boolean value=false;
		String inputVal;

		
				System.out.println("Enter Lease/Loan Amount (Rs):");				
				inputVal= in.nextLine();
				while(value == false) {					
					try {
						Lease_amount=Double.parseDouble(inputVal);
						value=true;						
					}
					catch(Exception e) {
						System.out.println("Error - Enter valid Loan amount:");
					}
				}
		
		value =false;
		System.out.println("Enter Interest Rate (Per year) :");
		inputVal=in.nextLine();
		while(value == false) {			
			try {
				interest_rate=Integer.parseInt(inputVal);
				value=true;				
			}			
			catch(Exception e) {
				System.out.println("Error - Enter valid Interest Rate :");
			}
		}
		
		value=false;
		System.out.println("Enter Repayment Period (months) :");
		inputVal=in.nextLine();
		while(value == false) {
			try {
				repayment_period=Integer.parseInt(inputVal);
				value=true;
				}
			catch(Exception e) {
				System.out.println("Error - Enter Repayment Period correctly :");
			}
		}
	     
	    in.close();
	    
	    rental_value=(Lease_amount*(interest_rate/12)/(1-((1/(Math.pow((1+(interest_rate/12)),repayment_period))))));
	    double output=(Math.round(rental_value*100))/100.0;		
	    System.out.println("Rental Value is :  "+" " + output);		
		System.out.println("Rental No\t"+"Rental Value\t\t"+"Interest Amount\t\t"+"Capital Amount\t"+"Capital Balance");
		System.out.println("0"+"\t\t\t\t\t\t\t\t"+Lease_amount);
		
		for(int i=1;i<=repayment_period;i++) {
			
			interest_amount=(Lease_amount*interest_rate)/12;
			capital_amount=(rental_value-interest_amount);
			capital_balance=(Lease_amount-capital_amount);
			Lease_amount=Lease_amount-capital_amount;			
			System.out.println(i+"\t\t"+output+"\t\t"+Math.round(interest_amount*100)/100.00+"\t\t"+Math.round(capital_amount*100)/100.00+"\t\t"+Math.round(capital_balance*100)/100.00);
					
		}		 	
	}		

}


