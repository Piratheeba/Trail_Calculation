/**
 * 
 */
/**
 * @author pc
 *
 */
module TrailCalcultion {
}